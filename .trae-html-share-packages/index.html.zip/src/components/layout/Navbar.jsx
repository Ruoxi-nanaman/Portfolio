import { ArrowUpRight } from "lucide-react";
import { cn } from "../../lib/utils.js";

const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "projects", label: "Projects" },
  { id: "contact", label: "Contact" },
];

export default function Navbar({ activeId }) {
  return (
    <header className="sticky top-0 z-50 border-b border-ink-700/40 bg-ink-900/70 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-[1200px] items-center justify-between px-6 sm:px-8">
        <a
          href="#home"
          className="font-serif text-2xl font-light tracking-wide text-text-base hover:text-aether-100 transition-colors"
        >
          Ruo xi
        </a>

        <nav aria-label="Primary" className="hidden md:block">
          <ul className="flex items-center gap-10">
            {NAV_LINKS.map((link) => (
              <li key={link.id}>
                <a
                  href={`#${link.id}`}
                  className={cn(
                    "group relative text-sm font-medium tracking-wide transition-colors duration-300",
                    activeId === link.id
                      ? "text-text-base"
                      : "text-text-dim hover:text-text-muted",
                  )}
                >
                  {link.label}
                  <span
                    className={cn(
                      "absolute -bottom-2 left-0 h-px bg-aether-300 transition-all duration-300",
                      activeId === link.id ? "w-full" : "w-0 group-hover:w-full",
                    )}
                  />
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <a
          href="#contact"
          className="hidden items-center gap-1.5 text-sm text-aether-100 hover:text-aether-50 transition-colors sm:inline-flex"
        >
          Get in touch <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      </div>
    </header>
  );
}
