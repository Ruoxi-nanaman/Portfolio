import { ArrowUpRight } from "lucide-react";
import { cn } from "../../lib/utils.js";

/**
 * Project preview mockups rendered as nested surfaces for depth.
 */
function SelenePreview() {
  return (
    <div className="relative h-full w-full overflow-hidden rounded-sm bg-ink-850">
      <div className="flex items-center justify-between border-b border-ink-700/60 px-4 py-2.5">
        <span className="text-[0.65rem] uppercase tracking-[0.18em] text-aether-300/70">
          selene / focus
        </span>
        <div className="flex gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-ink-500" />
          <span className="h-1.5 w-1.5 rounded-full bg-ink-500" />
          <span className="h-1.5 w-1.5 rounded-full bg-aether-400/60" />
        </div>
      </div>
      <div className="flex flex-col items-center justify-center px-6 pb-8 pt-10">
        <h4 className="font-serif text-2xl font-light text-text-base">
          A little space to think.
        </h4>
        <p className="mt-1.5 text-[0.7rem] text-text-dim">
          Leave the noise behind. Begin with one thing.
        </p>
        <div className="my-8 flex h-32 w-32 items-center justify-center rounded-full border border-aether-500/30 shadow-[inset_0_0_24px_rgba(110,168,216,0.08)]">
          <div className="text-center">
            <div className="font-serif text-3xl font-light text-text-base">
              25:00
            </div>
            <div className="mt-1 text-[0.6rem] uppercase tracking-[0.2em] text-text-dim">
              Focus Session
            </div>
          </div>
        </div>
        <div className="flex w-full items-center justify-between text-[0.7rem] text-text-dim">
          <div className="flex gap-4">
            <span className="text-aether-200">Focus</span>
            <span>Short break</span>
            <span>Long break</span>
          </div>
          <span className="uppercase tracking-[0.18em] text-aether-300">
            Start →
          </span>
        </div>
      </div>
    </div>
  );
}

function AtlasPreview() {
  const covers = [
    { title: "The Art of Noticing", tint: "bg-[#3a4a52]" },
    { title: "Still Waters", tint: "bg-[#6b5a48]" },
    { title: "A Field Guide to Wonder", tint: "bg-[#4a5868]" },
  ];
  return (
    <div className="relative h-full w-full overflow-hidden rounded-sm bg-ink-850">
      <div className="border-b border-ink-700/60 px-4 py-2.5">
        <span className="text-[0.65rem] uppercase tracking-[0.18em] text-aether-300/70">
          atlas / reading room
        </span>
      </div>
      <div className="px-5 pt-5">
        <h4 className="font-serif text-xl font-light text-text-base">
          Your next chapter awaits.
        </h4>
        <p className="mt-1 text-[0.7rem] text-text-dim">
          A quiet home for the books you love.
        </p>
      </div>
      <div className="flex gap-3 px-5 pb-5 pt-6">
        {covers.map((c) => (
          <div key={c.title} className="flex-1">
            <div
              className={cn(
                "flex aspect-[3/4] items-end rounded-sm p-2 shadow-lift",
                c.tint,
              )}
            >
              <span className="text-[0.55rem] leading-tight text-white/70">
                {c.title}
              </span>
            </div>
            <p className="mt-1.5 text-[0.6rem] text-text-dim">Currently reading</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function LumenPreview() {
  const lines = [
    "// keep what works",
    "const debounce = (fn, ms) => {",
    "  let t;",
    "  return (...a) => {",
    "    clearTimeout(t);",
    "    t = setTimeout(() => fn(...a), ms);",
    "  };",
    "};",
  ];
  return (
    <div className="relative h-full w-full overflow-hidden rounded-sm bg-ink-850">
      <div className="border-b border-ink-700/60 px-4 py-2.5">
        <span className="text-[0.65rem] uppercase tracking-[0.18em] text-aether-300/70">
          lumen / snippet library
        </span>
      </div>
      <div className="px-5 py-5 font-mono text-[0.7rem] leading-relaxed">
        {lines.map((line, i) => (
          <div key={i} className="flex gap-3">
            <span className="w-4 text-right text-ink-500">{i + 1}</span>
            <span
              className={cn(
                line.startsWith("//")
                  ? "text-text-dim"
                  : line.includes("(") || line.includes(")")
                    ? "text-aether-200"
                    : "text-text-muted",
              )}
            >
              {line}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

const PREVIEWS = {
  selene: SelenePreview,
  atlas: AtlasPreview,
  lumen: LumenPreview,
};

export default function ProjectCard({ project, featured = false }) {
  const Preview = PREVIEWS[project.id];

  return (
    <article
      className={cn(
        "group surface-panel relative overflow-hidden rounded-sm transition-all duration-500 ease-[var(--ease-soft)]",
        "hover:-translate-y-1 hover:border-aether-400/25 hover:shadow-elevated",
        featured ? "lg:grid lg:grid-cols-2" : "",
      )}
    >
      {/* Ambient corner glow */}
      <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-aether-700/10 blur-3xl transition-opacity duration-500 group-hover:opacity-100 opacity-60" />

      {/* Preview window */}
      <div
        className={cn(
          "relative p-5 sm:p-7",
          featured ? "border-r border-ink-700/40" : "border-b border-ink-700/40",
        )}
      >
        {Preview ? <Preview /> : <div className="aspect-video w-full" />}
      </div>

      {/* Details */}
      <div className="flex flex-col justify-between gap-6 p-6 sm:p-8">
        <div>
          <div className="flex items-center gap-3">
            <span className="font-serif text-sm text-text-dim">
              {project.number}
            </span>
            <span className="text-[0.65rem] uppercase tracking-[0.2em] text-aether-300/70">
              {project.tag}
            </span>
          </div>
          <h3 className="mt-4 font-serif text-3xl font-light tracking-tight text-text-base">
            {project.title}
          </h3>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-text-muted">
            {project.description}
          </p>
          <div className="mt-5 flex flex-wrap gap-x-3 gap-y-1.5">
            {project.tags.map((tag) => (
              <span key={tag} className="text-xs text-text-dim">
                {tag}
                <span className="mx-3 text-ink-500">·</span>
              </span>
            ))}
          </div>
        </div>

        <div className="hairline my-2" />

        <div className="flex items-center justify-between">
          <a
            href={project.links.view}
            className="inline-flex items-center gap-1.5 text-sm text-text-base hover:text-aether-100 transition-colors"
          >
            View project <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
          <a
            href={project.links.github}
            className="inline-flex items-center gap-1.5 text-sm text-text-muted hover:text-aether-100 transition-colors"
          >
            GitHub <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </article>
  );
}
