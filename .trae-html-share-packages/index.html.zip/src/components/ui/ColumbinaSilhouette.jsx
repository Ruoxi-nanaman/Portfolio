/**
 * Static side-view silhouette placeholder for the Columbina character.
 * The actual walking animation and loading-to-hero transition are deferred to a later stage.
 *
 * A simple, elegant side-profile figure in a long coat — kept as a clean silhouette
 * so it complements a professional developer portfolio rather than dominating it.
 */
export default function ColumbinaSilhouette({ className }) {
  return (
    <svg
      viewBox="0 0 320 520"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Silhouette of a figure in a long coat"
    >
      <defs>
        <linearGradient id="columbina-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#05070b" />
          <stop offset="60%" stopColor="#020305" />
          <stop offset="100%" stopColor="#000000" />
        </linearGradient>
        <linearGradient id="columbina-edge" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(110,168,216,0.35)" />
          <stop offset="55%" stopColor="rgba(110,168,216,0.08)" />
          <stop offset="100%" stopColor="rgba(110,168,216,0)" />
        </linearGradient>
      </defs>

      {/* Figure silhouette — side view, standing, long coat */}
      <g fill="url(#columbina-fill)" stroke="url(#columbina-edge)" strokeWidth="1">
        {/* Head + hair */}
        <path d="M168 54 c-22 0 -38 14 -38 38 c0 10 3 18 8 26 c-6 6 -10 16 -10 28 c0 18 10 30 22 38 c-14 8 -26 22 -30 40 l12 6 c6 -16 20 -28 36 -34 c10 4 22 4 32 -2 c12 -7 20 -20 20 -36 c0 -22 -14 -38 -36 -38 c-6 0 -12 1 -16 4 c2 -8 2 -16 0 -24 c-4 -14 -16 -20 -30 -20 z" />

        {/* Hair flowing down the back */}
        <path d="M130 120 c-20 6 -34 24 -36 48 c-2 20 4 34 14 44 c-4 8 -6 18 -6 30 c0 16 6 30 18 40 l10 -8 c-10 -8 -14 -20 -14 -32 c0 -10 2 -20 6 -28 c-6 -6 -10 -14 -10 -26 c0 -18 10 -32 26 -38 c-2 -10 -2 -20 2 -30 z" />

        {/* Neck */}
        <path d="M158 150 h20 v18 h-20 z" />

        {/* Coat body — flared silhouette */}
        <path d="M142 168 c-8 2 -16 8 -20 18 c-6 14 -4 30 2 44 c-10 8 -18 22 -20 38 l10 4 c2 -14 8 -24 16 -30 c2 30 8 62 18 92 l14 2 c8 -28 14 -60 16 -92 c10 6 18 18 20 32 c4 -16 -2 -30 -12 -40 c6 -14 8 -30 2 -44 c-4 -10 -12 -16 -20 -18 c-2 -16 -12 -26 -28 -26 s-26 10 -28 26 z" />

        {/* Coat opening / lapel line */}
        <path d="M168 172 c4 10 4 24 0 36 c-2 8 -2 18 0 28 v180" fill="none" stroke="rgba(110,168,216,0.12)" strokeWidth="1" />

        {/* Arms */}
        <path d="M142 176 c-14 2 -24 12 -26 28 c-2 14 4 24 12 32 c-2 8 -2 16 0 24 l10 -2 c-2 -8 -2 -16 0 -24 c6 -4 10 -12 12 -22 c2 -10 2 -20 0 -30 z" />
        <path d="M198 176 c14 2 22 10 24 24 c2 14 -2 26 -10 34 c2 8 2 16 0 24 l-10 -2 c2 -8 2 -16 0 -24 c-6 -4 -10 -12 -12 -22 c-2 -10 -2 -20 0 -30 z" />

        {/* Legs */}
        <path d="M150 410 h16 v90 h-16 z" />
        <path d="M174 410 h16 v90 h-16 z" />
      </g>
    </svg>
  );
}
