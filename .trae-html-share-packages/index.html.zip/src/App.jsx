import Navbar from "./components/layout/Navbar.jsx";
import Footer from "./components/layout/Footer.jsx";
import Home from "./sections/Home.jsx";
import About from "./sections/About.jsx";
import Projects from "./sections/Projects.jsx";
import Contact from "./sections/Contact.jsx";
import { useActiveSection } from "./hooks/useActiveSection.js";

const SECTION_IDS = ["home", "about", "projects", "contact"];

export default function App() {
  const activeId = useActiveSection(SECTION_IDS);

  return (
    <>
      <Navbar activeId={activeId} />
      <main>
        <Home />
        <About />
        <Projects />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
