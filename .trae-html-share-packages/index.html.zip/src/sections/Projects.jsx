import SectionHeading from "../components/ui/SectionHeading.jsx";
import ProjectCard from "../components/ui/ProjectCard.jsx";
import { projects } from "../data/projects.js";

export default function Projects() {
  const featured = projects.find((p) => p.featured);
  const rest = projects.filter((p) => !p.featured);

  return (
    <section id="projects" className="relative py-24 sm:py-32">
      {/* Ambient layer */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute right-0 top-32 h-72 w-72 rounded-full bg-aether-900/20 blur-[100px]" />
      </div>

      <div className="relative mx-auto max-w-[1200px] px-6 sm:px-8">
        <SectionHeading
          eyebrow="02 / Selected Explorations"
          title="Built with intention."
          subtitle="A few ideas brought to life through design and development."
        />

        <p className="mt-10 text-[0.7rem] uppercase tracking-[0.22em] text-text-dim">
          Concept Projects — Replace with your own work
        </p>

        {/* Featured card */}
        {featured && (
          <div className="mt-6">
            <ProjectCard project={featured} featured />
          </div>
        )}

        {/* Secondary cards */}
        {rest.length > 0 && (
          <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            {rest.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        )}

        <p className="mt-12 font-serif text-xl font-light italic text-text-muted">
          Small experiments. Meaningful possibilities.
        </p>
      </div>
    </section>
  );
}
