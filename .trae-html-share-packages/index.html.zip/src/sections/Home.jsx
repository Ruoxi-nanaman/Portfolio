import { ArrowUpRight, ArrowDown } from "lucide-react";
import Button from "../components/ui/Button.jsx";
import ColumbinaSilhouette from "../components/ui/ColumbinaSilhouette.jsx";

export default function Home() {
  return (
    <section
      id="home"
      className="relative min-h-[calc(100vh-5rem)] overflow-hidden"
    >
      {/* Layered background ambiance */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-ink-900 via-ink-900/60 to-void-950" />
        {/* Ambient blue glow behind the figure */}
        <div className="absolute right-[8%] top-1/2 h-[520px] w-[520px] -translate-y-1/2 rounded-full bg-aether-800/30 blur-[110px]" />
        <div className="absolute right-[14%] top-1/2 h-[300px] w-[300px] -translate-y-1/2 rounded-full bg-aether-700/25 blur-[70px]" />
      </div>

      <div className="relative mx-auto grid max-w-[1200px] grid-cols-1 items-center gap-12 px-6 py-16 sm:px-8 lg:grid-cols-12 lg:gap-8 lg:py-24">
        {/* Left: text */}
        <div className="lg:col-span-7">
          <p className="eyebrow mb-6">Portfolio / Developer & Creative Thinker</p>

          <p className="font-serif text-2xl font-light text-text-muted sm:text-3xl">
            Hello, I&apos;m
          </p>

          <h1 className="mt-1 font-serif text-[2.75rem] font-light leading-[1.05] tracking-tight text-text-base sm:text-6xl lg:text-7xl">
            Jeru Emmanuel
            <br />
            Pabutoy
          </h1>

          <p className="mt-8 font-serif text-xl font-light italic text-aether-100/90 sm:text-2xl">
            Building meaningful digital experiences
            <br />
            through code and creativity.
          </p>

          <p className="mt-6 max-w-lg text-sm leading-relaxed text-text-muted">
            I turn thoughtful ideas into intuitive software. Exploring the space
            where clean code meets considered design.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Button variant="primary" as="a" href="#projects">
              Explore projects <ArrowUpRight className="h-4 w-4" />
            </Button>
            <Button variant="ghost" as="a" href="#about">
              About me
            </Button>
          </div>
        </div>

        {/* Right: Columbina silhouette on illuminated ground */}
        <div className="relative flex items-end justify-center lg:col-span-5">
          <div className="relative flex h-[460px] w-full items-end justify-center sm:h-[540px]">
            {/* Celestial halo behind the figure */}
            <div className="pointer-events-none absolute inset-x-0 top-0 mx-auto h-[380px] w-[380px] rounded-full bg-aether-700/15 blur-[60px]" />

            {/* Soft illuminated ground */}
            <div className="absolute bottom-0 left-1/2 h-24 w-[460px] max-w-full -translate-x-1/2 rounded-[50%] bg-aether-600/15 blur-2xl" />
            <div className="absolute bottom-0 left-1/2 h-px w-[300px] -translate-x-1/2 bg-gradient-to-r from-transparent via-aether-300/40 to-transparent" />

            {/* Figure */}
            <div className="relative z-10 h-full">
              <ColumbinaSilhouette className="h-full w-auto drop-shadow-[0_0_30px_rgba(110,168,216,0.18)]" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="relative mx-auto flex max-w-[1200px] items-end justify-between px-6 pb-10 sm:px-8">
        <a
          href="#about"
          className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-text-dim hover:text-aether-100 transition-colors"
        >
          Scroll to explore <ArrowDown className="h-3.5 w-3.5" />
        </a>
        <span className="text-xs uppercase tracking-[0.22em] text-text-dim">
          01 / The Beginning
        </span>
      </div>
    </section>
  );
}
