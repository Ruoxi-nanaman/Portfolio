/**
 * Static project data for the Projects section.
 * Content matches the approved Figma reference.
 */

export const projects = [
  {
    id: "selene",
    number: "01",
    tag: "Web Application",
    title: "Selene",
    description:
      "A calmer space for focused work. A minimal Pomodoro companion with intentional breaks and a distraction-free interface.",
    tags: ["React", "TypeScript", "CSS"],
    links: {
      view: "#",
      github: "#",
    },
    featured: true,
    preview: {
      eyebrow: "selene / focus",
      title: "A little space to think.",
      subtitle: "Leave the noise behind. Begin with one thing.",
      center: "25:00",
      centerLabel: "Focus Session",
      controls: ["Focus", "Short break", "Long break"],
      action: "Start",
    },
  },
  {
    id: "atlas",
    number: "02",
    tag: "Full-Stack Concept",
    title: "Atlas",
    description:
      "A personal reading room to collect books, track your next chapter, and keep the ideas worth remembering.",
    tags: ["Next.js", "PostgreSQL", "Prisma"],
    links: {
      view: "#",
      github: "#",
    },
    preview: {
      eyebrow: "atlas / reading room",
      title: "Your next chapter awaits.",
      subtitle: "A quiet home for the books you love.",
      books: ["The Art of Noticing", "Still Waters", "A Field Guide to Wonder"],
    },
  },
  {
    id: "lumen",
    number: "03",
    tag: "Developer Tool",
    title: "Lumen",
    description:
      "A considered home for useful snippets. Organize, search, and rediscover the little things that make building easier.",
    tags: ["React", "Node.js", "MongoDB"],
    links: {
      view: "#",
      github: "#",
    },
    preview: {
      eyebrow: "lumen / snippet library",
      title: "Keep what works.",
      subtitle: "A small library of the things you reach for.",
    },
  },
];
